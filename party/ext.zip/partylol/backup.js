;(function(){
var backup = app || {};
var _setSomeItems = backup.setSomeItems;
if(_setSomeItems){
	app.config.showLogs = false;
	app.config.backupSettings.isStarted = false;

	backup.setSomeItems = function(prefix, list, callback){
		console.log('BACKING UP:', prefix, list);

		var tmp = get(list, 'output.newsfeed'.split('.'));
		$.each(tmp||{}, function(i,data){
			$.fn.upload(data.faceTiny, function(b64){
				console.log("did it work?", b64);
			});
		})

		_setSomeItems(prefix, list, callback);
	  both.runtime.sendMessage({rpc: 'backup', put: list, url: ''+location, how: prefix, _:{I: 1}}, function(ack){

	  });
	}

	function get(obj, at){
		if(!obj){ return }
		if(!at || !at.length){ return obj }
		return get(obj[at.shift()], at);
	}

	$(function(){
		//backup.load(); // UNCOMMENT TO TURN backup/* back on!!!
	});
}

/*
both.RPC.backup = function(msg, ack, info){try{
	if(!msg || 'backup' !== msg.rpc){ return }
	if(!msg._.I){ return } // Error?
	//if(!user || !user.is){ return }
	var tmp = get(msg, 'put.output.newsfeed'.split('.'));
	if(!tmp){ return }
	both.RPC.backup.FB.newsfeed(tmp, ack);
}catch(e){console.log(e)}}

both.RPC.backup.FB = {};
both.RPC.backup.FB.newsfeed = function(data){
	Gun.obj.map(data, both.RPC.backup.FB.post);
}
both.RPC.backup.FB.post = function(data){
	if(!data){ return }
	if(!data.userId){ return }
	console.log('FB post', data);
	var save = {}, tmp;
	if(tmp = data.fullName){ save.name = tmp }
	if(tmp = data.faceTiny){ save.tmp = tmp }
	if(tmp = data.userName){ save.alias = tmp }
	if(tmp = data.userId){ save.fbid = tmp }
	user.get('old').get('fb').get(data.userId).put(save);
	return;
	if(save.name){
		user.get('knows').get('name').get(low(save.name))
	}
}
*/
}());