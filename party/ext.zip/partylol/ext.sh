rsync -av ~/Code/fbs/chrome-extension6/js/* ./backup
rm ./backup/init.js
rm ./backup/inject.js
rm ./backup/background.js