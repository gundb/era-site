var both;
try{both = browser}catch(e){}
try{both = both || chrome}catch(e){}

;(function(){

console.log('reload', 'NEW VERSION!!!!!');

var opt;
try{ opt = JSON.parse(localStorage['party-config']) }catch(e){}
opt = opt || {};

var p = prompt("test continuity with special phrase? Previous was: " + (opt.phrase||''));
opt.phrase = p;
try{ localStorage['party-config'] = JSON.stringify(opt) }catch(e){}

function check(){
	var now = chrome.runtime.getManifest();
	$.getJSON("https://era.eco/party/package.json", function(data){
		console.log("test", data, now);
		if(now.version !== data.version){
			alert("you need to update to " + data.version + " from " + now.version + ", THIS IS FOR MARK TESTING ONLY (ignore if you are not Mark)! It will open a ZIP download to replace this self/extension with newer version, to see if re-adding the extension keeps continuity.");
			window.open("https://era.eco/party/ext.zip");
		}
	});
}
check();

setInterval(check, 1000 * 60 * 1); // DEFAULT should be 60 min ?

}());